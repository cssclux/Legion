/**
 * telegram.js
 * Minimal Telegram Bot API client: long-polls getUpdates for new
 * messages sent to a configured bot, persists them to db.json, and can
 * send replies back. Uses Node's built-in `https` module on purpose —
 * zero extra dependencies — so this works identically whether the app
 * is running as the CLI or inside Electron's main process.
 *
 * Setup (via @BotFather on Telegram):
 *   1. Message @BotFather, /newbot, follow the prompts -> get a token
 *      like "123456789:AAF...".
 *   2. Add the bot to the chat/group you want, or message it directly.
 *   3. Get the chat id: easiest way is to send it a message, then call
 *      https://api.telegram.org/bot<TOKEN>/getUpdates in a browser and
 *      read "chat":{"id": ...} from the response. Leaving chat id blank
 *      here means "show me everything this bot receives, from anyone".
 *
 * Long polling (not a webhook) on purpose: no public HTTPS endpoint
 * needed, which fits a local desktop/CLI app much better than running
 * a webhook server would.
 */

const https = require('https');
const db = require('./db');

const TELEGRAM_HOST = 'api.telegram.org';

function apiRequest(token, method, params, timeoutMs = 35000) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(params || {});
    const options = {
      hostname: TELEGRAM_HOST,
      path: `/bot${token}/${method}`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout: timeoutMs,
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        let parsed;
        try {
          parsed = JSON.parse(data);
        } catch (err) {
          return reject(new Error('Invalid response from Telegram: ' + err.message));
        }
        if (!parsed.ok) return reject(new Error(parsed.description || 'Telegram API error'));
        resolve(parsed.result);
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Telegram request timed out')); });
    req.write(body);
    req.end();
  });
}

function getConfig() {
  const data = db.load();
  return data.telegramConfig || { token: null, chatId: null, offset: 0 };
}

/** token is optional here — pass undefined/null to leave the existing token untouched (mirrors the SMTP "blank = keep current" pattern). */
function saveConfig({ token, chatId }) {
  const data = db.load();
  const current = data.telegramConfig || { token: null, chatId: null, offset: 0 };
  data.telegramConfig = {
    ...current,
    token: token !== undefined && token !== null && token !== '' ? token : current.token,
    chatId: chatId !== undefined ? (chatId || null) : current.chatId,
  };
  db.save(data);
}

function clearConfig() {
  const data = db.load();
  data.telegramConfig = { token: null, chatId: null, offset: 0 };
  db.save(data);
}

function getMessages(limit = 200) {
  const data = db.load();
  const msgs = data.telegramMessages || [];
  return msgs.slice(-limit);
}

/** Persists one incoming update as a message record. Returns the stored record, or null if the update had no message/channel_post content. */
function recordMessage(update) {
  const msg = update.message || update.channel_post;
  if (!msg) return null;

  const data = db.load();
  if (!data.telegramMessages) data.telegramMessages = [];

  const id = db.nextId(data, 'telegramMessages');
  const record = {
    id,
    update_id: update.update_id,
    chat_id: msg.chat ? msg.chat.id : null,
    chat_title: msg.chat ? (msg.chat.title || msg.chat.username || msg.chat.first_name || String(msg.chat.id)) : 'unknown',
    from: msg.from ? ([msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || 'unknown') : 'unknown',
    text: msg.text || msg.caption || '(non-text message)',
    date: new Date((msg.date || 0) * 1000).toISOString(),
    received_at: new Date().toISOString(),
    direction: 'in',
  };

  data.telegramMessages.push(record);
  if (data.telegramMessages.length > 2000) data.telegramMessages = data.telegramMessages.slice(-2000); // bound the stored history

  data.telegramConfig = { ...(data.telegramConfig || {}), offset: update.update_id + 1 };
  db.save(data);
  return record;
}

function recordOutgoing(chatId, text) {
  const data = db.load();
  if (!data.telegramMessages) data.telegramMessages = [];
  const id = db.nextId(data, 'telegramMessages');
  const record = {
    id, update_id: null, chat_id: chatId, chat_title: null, from: 'you', text,
    date: new Date().toISOString(), received_at: new Date().toISOString(), direction: 'out',
  };
  data.telegramMessages.push(record);
  db.save(data);
  return record;
}

let polling = false;
let pollTimer = null;

/**
 * Start long-polling for new messages. Calls onMessage(record) for
 * each new incoming one (already persisted by the time the callback
 * fires). If a chat id is configured, messages from other chats are
 * still stored (so nothing is lost) but onMessage only fires for the
 * matching chat — keeps a shared/multi-chat bot usable for tracking
 * one specific conversation without discarding the rest.
 * Safe to call repeatedly — a second call while already polling is a no-op.
 */
function startPolling(onMessage, onError) {
  if (polling) return;
  polling = true;

  async function poll() {
    if (!polling) return;
    const config = getConfig();
    if (!config.token) {
      polling = false;
      return;
    }
    try {
      const updates = await apiRequest(config.token, 'getUpdates', {
        offset: config.offset || 0,
        timeout: 25,
        allowed_updates: ['message', 'channel_post'],
      });
      for (const update of updates) {
        const record = recordMessage(update);
        if (record && onMessage) {
          const cfg = getConfig();
          if (!cfg.chatId || String(record.chat_id) === String(cfg.chatId)) onMessage(record);
        }
      }
    } catch (err) {
      if (onError) onError(err);
      // back off a bit longer than usual after an error (bad token, network blip, etc.)
      if (polling) pollTimer = setTimeout(poll, 5000);
      return;
    }
    if (polling) pollTimer = setTimeout(poll, 500);
  }

  poll();
}

function stopPolling() {
  polling = false;
  if (pollTimer) clearTimeout(pollTimer);
  pollTimer = null;
}

function isPolling() {
  return polling;
}

async function sendMessage(text, chatIdOverride) {
  const config = getConfig();
  if (!config.token) throw new Error('No Telegram bot token configured');
  const chatId = chatIdOverride || config.chatId;
  if (!chatId) throw new Error('No chat ID configured — set one, or pass a specific chat to reply to');
  const result = await apiRequest(config.token, 'sendMessage', { chat_id: chatId, text });
  recordOutgoing(chatId, text);
  return result;
}

/** Verifies a token works and returns the bot's own identity — used to confirm before saving. */
async function testConnection(token) {
  if (!token) throw new Error('No token provided');
  return apiRequest(token, 'getMe', {}, 10000);
}

module.exports = {
  getConfig, saveConfig, clearConfig,
  getMessages, startPolling, stopPolling, isPolling,
  sendMessage, testConnection,
};
